<?php require 'inc/header.php'; ?>
<?php
	if($_SERVER['REQUEST_METHOD'] == 'POST'){
		$firstname = $fm->validation($_POST['firstname']);
		$lastname = $fm->validation($_POST['lastname']);
		$email = $fm->validation($_POST['email']);
		$body = $fm->validation($_POST['body']);

		$error = "";
		if(empty($firstname)){
			$error = "Firstname is not empty!";
		}elseif(empty($lastname)){
			$error = "Lastname is not empty!";
		}elseif(empty($email)){
			$error = "Email is not empty!";
		}elseif(!filter_var($email, FILTER_VALIDATE_EMAIL)){
			$error = "invailed email!";
		}elseif(empty($body)){
			$error = "Massage is not empty!";
		}else{
			$query = "INSERT INTO `tbl_contact`(`firstname`, `lastname`, `email`, `bdoy`) VALUES ('$firstname', '$lastname', '$email', '$body') ";
            $inserted_rows = $db->insert($query);
            if ($inserted_rows) {
                $success = "MSG send successfully.";
            }else {
                $error = "Massage is not send!";
            }
		}
	}
?>			
	<div class="contentsection contemplete clear">
		<div class="maincontent clear">
			<div class="about">
				<h2>Contact us</h2>
				<?php if(isset($error)){echo "<span style='color:red'>$error </span>"; } ?>
				<?php if(isset($success)){echo "<span style='color:green'>$success </span>"; } ?>
			<form action="" method="post">
				<table>
				<tr>
					<td>Your First Name:</td>
					<td>
					<input type="text" name="firstname" placeholder="Enter first name" />
					</td>
				</tr>
				<tr>
					<td>Your Last Name:</td>
					<td>
					<input type="text" name="lastname" placeholder="Enter Last name" />
					</td>
				</tr>
				
				<tr>
					<td>Your Email Address:</td>
					<td>
					<input type="text" name="email" placeholder="Enter Email Address" />
					</td>
				</tr>
				<tr>
					<td>Your Message:</td>
					<td>
					<textarea name="body"></textarea>
					</td>
				</tr>
				<tr>
					<td></td>
					<td>
					<input type="submit" name="send" value="send"/>
					</td>
				</tr>
		</table>
	<form>				
 </div>

		</div>
	
<?php require 'inc/sidebar.php';  ?>
<?php require 'inc/footer.php'; ?>