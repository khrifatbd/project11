-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 11, 2022 at 04:52 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_blog`
--

-- --------------------------------------------------------

--
-- Table structure for table `bd_titel_slogan`
--

CREATE TABLE `bd_titel_slogan` (
  `id` int(11) NOT NULL,
  `logo_titel` varchar(255) NOT NULL,
  `slogan` varchar(255) NOT NULL,
  `logo` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `bd_titel_slogan`
--

INSERT INTO `bd_titel_slogan` (`id`, `logo_titel`, `slogan`, `logo`) VALUES
(1, 'KH RIFAT', 'Kh Rifat world', 'logo.png');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_cat`
--

CREATE TABLE `tbl_cat` (
  `id` int(25) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_cat`
--

INSERT INTO `tbl_cat` (`id`, `name`) VALUES
(1, 'java'),
(2, 'php'),
(3, 'html'),
(4, 'css'),
(12, 'Education'),
(14, 'javascript');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_contact`
--

CREATE TABLE `tbl_contact` (
  `id` int(11) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `bdoy` text NOT NULL,
  `stutas` int(11) NOT NULL DEFAULT 0,
  `date` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_contact`
--

INSERT INTO `tbl_contact` (`id`, `firstname`, `lastname`, `email`, `bdoy`, `stutas`, `date`) VALUES
(4, 'hablu', 'hasan', 'hablu@gmail.com', 'ere are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomi.ere are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomi.ere are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomi.', 1, '2022-04-06'),
(5, 'kh', 'rifat', 'kh@gmail.com', 'here are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomi...here are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomi...here are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomi...here are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomi...', 1, '2022-04-06'),
(6, 'sha', 'alom', 'sha@gmail.com', 'Jodi same image use korte chai post a tahole akta image unlink korle baki gula...Jodi same image use korte chai post a tahole akta image unlink korle baki gula...Jodi same image use korte chai post a tahole akta image unlink korle baki gula...', 0, '2022-04-06');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_footer`
--

CREATE TABLE `tbl_footer` (
  `id` int(11) NOT NULL,
  `note` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_footer`
--

INSERT INTO `tbl_footer` (`id`, `note`) VALUES
(1, 'Copyright Kh Rifat');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_page`
--

CREATE TABLE `tbl_page` (
  `id` int(11) NOT NULL,
  `name` varchar(254) NOT NULL,
  `titel` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL,
  `body` mediumtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_page`
--

INSERT INTO `tbl_page` (`id`, `name`, `titel`, `img`, `body`) VALUES
(5, 'Privacy Policy', 'Privacy Policy for khrifat', '5778e403b8.png', 'At khrifat, accessible from https://khrifatbdnu.w3spaces.com/, one of our main priorities is the privacy of our visitors. This Privacy Policy document contains types of information that is collected and recorded by khrifat and how we use it.\r\n\r\nIf you have additional questions or require more information about our Privacy Policy, do not hesitate to contact us.\r\n\r\nThis Privacy Policy applies only to our online activities and is valid for visitors to our website with regards to the information that they shared and/or collect in khrifat. This policy is not applicable to any information collected offline or via channels other than this website. Our Privacy Policy was created with the help of the Free Privacy Policy Generator.'),
(7, 'DEMC', 'DEMC for kh rifat', '6987a64060.png', ', but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including            also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including        At khrifat, accessible from https://khrifatbdnu.w3spaces.com/, one of our main priorities is the privacy of our visitors. This Privacy Policy document contains types of information that is collected and recorded by khrifat and how we use it. If you have additional questions or require more information about our Privacy Policy, do not hesitate to contact us. This Privacy Policy applies only to our online activities and is valid for visitors to our website with regards to the information that they shared and/or collect in khrifat. This policy is not applicable to any information collected offline or via channels other than this website. Our Privacy Policy was created with the help of the Free Privacy Policy Generator.');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_post`
--

CREATE TABLE `tbl_post` (
  `id` int(11) NOT NULL,
  `cat` int(25) NOT NULL,
  `titel` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `img` varchar(255) NOT NULL,
  `author` varchar(50) NOT NULL,
  `tags` varchar(255) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp(),
  `userid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_post`
--

INSERT INTO `tbl_post` (`id`, `cat`, `titel`, `body`, `img`, `author`, `tags`, `date`, `userid`) VALUES
(15, 1, 'Education titel goes here u', ' here are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       ', '17d6c8bbc0.png', 'treacher update', 'education update dd', '2022-03-30 15:28:18', 0),
(16, 3, 'java post titel goes here', '                                                                        Jodi same image use korte chai post a tahole akta image unlink korle baki gula o ar kaj kore na...................ei somossa kivabe solve korbo?? Dhorum php er 4 ta post a 4 ta tei  ami PHP er same image use korlam.............delete korle post baki gula jeno kaj kore amon way ache ki?Jodi same image use korte chai post a tahole akta image unlink korle baki gula o ar kaj kore na...................ei somossa kivabe solve korbo?? Dhorum php er 4 ta post a 4 ta tei  ami PHP er same image use korlam.............delete korle post baki gula jeno kaj kore amon way ache ki?Jodi same image use korte chai post a tahole akta image unlink korle baki gula o ar kaj kore na...................ei somossa kivabe solve korbo?? Dhorum php er 4 ta post a 4 ta tei  ami PHP er same image use korlam.............delete korle post baki gula jeno kaj kore amon way ache ki?                                                                                                                                                                                        ', 'e9a0bc63ea.png', 'dd', 'dd ', '2022-03-31 10:23:59', 0),
(17, 3, 'java update', '                                             simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of \"de Finibus Bonorum et Malorum\" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem                                                                                                                                  ', '726ee8d25c.png', 'admin', 'java programing', '2022-03-31 10:27:53', 0),
(20, 12, 'Education titel goes here 04', '                    odi same image use korte chai post a tahole akta image unlink korle baki gulaodi same image use korte chai post a tahole akta image unlink korle baki gulaodi same image use korte chai post a tahole akta image unlink korle baki gulaodi same image use korte chai post a tahole akta image unlink korle baki gulaodi same image use korte chai post a tahole akta image unlink korle baki gula            ', '93229b7f48.png', 'admin', 'education', '2022-04-06 11:50:14', 0),
(21, 14, 'javascript titel goes here 14', '            মিজানুর রহমান আজহারির  সুলিল কন্ঠে সেরা ইংলিশ গজল । মিজানুর রহমান আজহারী গজল । পবিত্র বানীমিজানুর রহমান আজহারির  সুলিল কন্ঠে সেরা ইংলিশ গজল । মিজানুর রহমান আজহারী গজল । পবিত্র বানীমিজানুর রহমান আজহারির  সুলিল কন্ঠে সেরা ইংলিশ গজল । মিজানুর রহমান আজহারী গজল । পবিত্র বানীমিজানুর রহমান আজহারির  সুলিল কন্ঠে সেরা ইংলিশ গজল । মিজানুর রহমান আজহারী গজল । পবিত্র বানীমিজানুর রহমান আজহারির  সুলিল কন্ঠে সেরা ইংলিশ গজল । মিজানুর রহমান আজহারী গজল । পবিত্র বানী                    ', '6e2c7e0a7f.png', ' মিজানুর রহমান আজহারির', ' মিজানুর রহমান আজহারির', '2022-04-06 11:51:20', 0),
(22, 2, 'dddddddddd', ' Learn how to create a cms style blog website in php oop and mysqli (Live web development video tutorials in Bangla)', 'c681dc86ec.jpeg', 'sifat', 'php', '2022-04-08 05:38:50', 11);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_slider`
--

CREATE TABLE `tbl_slider` (
  `id` int(11) NOT NULL,
  `titel` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_slider`
--

INSERT INTO `tbl_slider` (`id`, `titel`, `img`) VALUES
(5, 'first slider goes here', '1306d27d99.jpg'),
(6, 'slider post 2', '8196fe8c75.jpg'),
(7, 'silder titel goes here3', '577ab07a40.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_social`
--

CREATE TABLE `tbl_social` (
  `id` int(11) NOT NULL,
  `fb` varchar(255) NOT NULL,
  `tw` varchar(255) NOT NULL,
  `ln` varchar(255) NOT NULL,
  `gp` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_social`
--

INSERT INTO `tbl_social` (`id`, `fb`, `tw`, `ln`, `gp`) VALUES
(1, 'https://www.facebook.com/khrifatbd', 'https://twitter.com/', 'https://www.linkedin.com/', 'https://google.com');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_theme`
--

CREATE TABLE `tbl_theme` (
  `id` int(11) NOT NULL,
  `theme` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_theme`
--

INSERT INTO `tbl_theme` (`id`, `theme`) VALUES
(1, 'blue');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `details` text NOT NULL,
  `role` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`id`, `name`, `username`, `password`, `email`, `details`, `role`) VALUES
(3, 'Rifat', 'kh', '202cb962ac59075b964b07152d234b70', 'kh@gmail.com', 'hlw i am kh Rifat. I am a web Developer.', 0),
(8, 'sh sifat', 'sh', '202cb962ac59075b964b07152d234b70', '', '', 0),
(9, 'editor', 'editor', '202cb962ac59075b964b07152d234b70', 'admin@gmail.com', '60s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing softwa', 2),
(11, 'sifat', 'author', '202cb962ac59075b964b07152d234b70', 'sh@gmail.com', 'simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000...simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000...simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000...', 1),
(13, '', 'ddd', '202cb962ac59075b964b07152d234b70', 'dd@g.com', '', 1),
(14, '', 'admin', '202cb962ac59075b964b07152d234b70', 'admin@gmail.com', '', 0),
(15, '', 'dd', '77963b7a931377ad4ab5ad6a9cd718aa', 'ddd@g.com', '', 2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bd_titel_slogan`
--
ALTER TABLE `bd_titel_slogan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_cat`
--
ALTER TABLE `tbl_cat`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_contact`
--
ALTER TABLE `tbl_contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_footer`
--
ALTER TABLE `tbl_footer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_page`
--
ALTER TABLE `tbl_page`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_post`
--
ALTER TABLE `tbl_post`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_slider`
--
ALTER TABLE `tbl_slider`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_social`
--
ALTER TABLE `tbl_social`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_theme`
--
ALTER TABLE `tbl_theme`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bd_titel_slogan`
--
ALTER TABLE `bd_titel_slogan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_cat`
--
ALTER TABLE `tbl_cat`
  MODIFY `id` int(25) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `tbl_contact`
--
ALTER TABLE `tbl_contact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tbl_footer`
--
ALTER TABLE `tbl_footer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_page`
--
ALTER TABLE `tbl_page`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tbl_post`
--
ALTER TABLE `tbl_post`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `tbl_slider`
--
ALTER TABLE `tbl_slider`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tbl_social`
--
ALTER TABLE `tbl_social`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_theme`
--
ALTER TABLE `tbl_theme`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
