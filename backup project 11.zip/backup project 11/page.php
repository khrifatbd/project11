
<?php require 'inc/header.php'; ?>
<?php
    if(isset($_GET['pageid'])){
        $pageid = $_GET['pageid'];

    }else{
        echo "page not found";
    }
?>
<?php 
     $query = "SELECT * FROM `tbl_page` where id= '$pageid'";
     $page = $db->select($query);
     if($page){
         while($pagename = $page->fetch_assoc()){ 
 ?>  
<div class="contentsection contemplete clear">
	<div class="maincontent clear">   		
		<div class="about">
			<h2><?= $pagename['titel']; ?></h2>
			<img src="admin/upload/<?= $pagename['img']; ?>" alt="">
			<p> <?= $pagename['body']; ?></p>
		</div>
	</div>
	<?php } }else{
		header('location:404.php');
	} ?> 	
	
<?php require 'inc/sidebar.php';  ?>
<?php require 'inc/footer.php'; ?>