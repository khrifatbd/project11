
<?php require 'inc/header.php'; ?>
<?php
 if(!isset($_GET['id']) || $_GET['id'] == NULL){
	header('location: 404.php');
 }else{
	 $id = $_GET['id'];
 }
?>
<div class="contentsection contemplete clear">
	<div class="maincontent clear">
		<div class="about">
<?php
	$query = "SELECT * FROM `tbl_post` WHERE `id` = $id";
	$post = $db->select($query);
	if($post){
		while($result = $post->fetch_assoc()){
?>
			<h2><?= $result['titel']; ?></h2>
			<h4><?= $fm->formatDate($result['date']); ?> <?= $result['author']; ?></h4>
			<img src="admin/upload/<?= $result['img'];?>" alt="post image"/>
			<p><?= $result['body']; ?></p>
<br>	
			<div class="relatedpost clear">
				<h2>Related articles</h2>
				<?php 
				$cat_id = $result['cat'];
				$query_releted = "SELECT * FROM `tbl_post` WHERE `cat` = '$cat_id' order by rand() limit 6";
				$releted_post = $db->select($query_releted);
				if($releted_post){
					while($r_result = $releted_post->fetch_assoc()){
				?>
				<a href="post.php?id=<?= $r_result['id']; ?>"> <img src="admin/upload/<?= $r_result['img'];?>" alt="post image"/></a>
				<?php } }else{
					echo "No releted Post!";
			}	} ?>
			</div>
			<?php
	}else{ header('location:404.php'); 
	} ?>		
</div>

	</div>

<?php require 'inc/sidebar.php';  ?>
<?php require 'inc/footer.php'; ?>