﻿<?php require 'inc/header.php'; ?>
<?php require 'inc/sidebar.php'; ?>
               
           
<style>
    .left-side{
float: left; width: 75%
    }
    .right-side{
        float:left; width: 25%
    }
    .right-side img{
        width:80%;
    }
</style>
        <div class="grid_10">
<?php
     $query = "SELECT * FROM `bd_titel_slogan` WHERE `id` = 1";
     $blog_titel = $db->select($query);
     if($blog_titel){
         while($result = $blog_titel->fetch_assoc()){ 
 ?>          
   
            <div class="box round first grid">
                <h2>Update Site Title and Description</h2>
 <?php
 if(isset($_POST['update_titel'])){
    $slogan = $_POST['slogan'];
    $logo_titel = $_POST['logo_titel'];

    $permited  = array('png');
    $file_name = $_FILES['logo']['name'];
    $file_size = $_FILES['logo']['size'];
    $file_temp = $_FILES['logo']['tmp_name'];

    $div = explode('.', $file_name);
    $file_ext = strtolower(end($div));
    $same_img = 'logo'.'.'.$file_ext;
    $uploaded_image = "img/logo/".$same_img;
   
        $post_query = "UPDATE `bd_titel_slogan` SET `logo_titel`='$logo_titel', `slogan`='$slogan',`logo`='$same_img' WHERE `id` = '1'";
        $update_post = $db->update($post_query);
        if($update_post){
            echo "<span class='success'> Titel, Solgan & img updated successfully</span>";
            move_uploaded_file($file_temp, $uploaded_image);
        }
}   
 ?>   
                <div class="block sloginblock">  
                <div class="left-side">              
                 <form action="" method="POST" enctype="multipart/form-data">
                    <table class="form">	
						 <tr>
                            <td>
                                <label>website titel</label>
                            </td>
                            <td>
                                <input type="text" value="<?= $result['logo_titel']; ?>"  name="logo_titel" class="medium" />
                            </td>
                        </tr>	
						 <tr>
                            <td>
                                <label>Website Slogan</label>
                            </td>
                            <td>
                                <input type="text" value="<?= $result['slogan']; ?>"  name="slogan" class="medium" />
                            </td>
                        </tr>
						 <tr>
                            <td>
                                <label>Upload Logo</label>
                            </td>
                            <td>
                                <input type="file" name ="logo" />
                            </td>
                        </tr>
						 
						
						 <tr>
                            <td>
                            </td>
                            <td>
                                <input type="submit" name="update_titel" Value="Update" />
                            </td>
                        </tr>
                    </table>
                    </form>
                    </div> 
                    
                    <div class="right-side">
                        <img src="img/logo/<?=$result['logo']; ?>" alt="logo">
                    </div>    
                </div>
            </div>
        </div>
        <?php }} ?>  
       
<?php require 'inc/footer.php'; ?>
