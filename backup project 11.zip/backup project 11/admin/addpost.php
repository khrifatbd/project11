﻿<?php require 'inc/header.php'; ?>
<?php require 'inc/sidebar.php'; ?>
        <div class="grid_10">
            <div class="box round first grid">
                <h2>Add New Post</h2>
<?php
 if(isset($_POST['submit'])){
    $titel = $_POST['titel'];
    $cat = $_POST['cat'];
    $body = $_POST['body'];
    $tags = $_POST['tags'];
    $author = $_POST['author'];
    $userid = $_POST['userid'];

    $permited  = array('jpg', 'jpeg', 'png', 'gif');
    $file_name = $_FILES['img']['name'];
    $file_size = $_FILES['img']['size'];
    $file_temp = $_FILES['img']['tmp_name'];

    $div = explode('.', $file_name);
    $file_ext = strtolower(end($div));
    $unique_image = substr(md5(time()), 0, 10).'.'.$file_ext;
    $uploaded_image = "upload/".$unique_image;

    if (empty($file_name) || empty($titel) || empty($cat) || empty($body) || empty($author) || empty($tags)) {
        echo "<span class='error'>Filed must not be empty!</span>";
       }elseif ($file_size >1048567) {
        echo "<span class='error'>Image Size should be less then 1MB!
        </span>";
       } elseif (in_array($file_ext, $permited) === false) {
        echo "<span class='error'>You can upload only:-".implode(', ', $permited)."</span>";
       } else{
            move_uploaded_file($file_temp, $uploaded_image);
            $query = "INSERT INTO `tbl_post`( `cat`, `titel`, `body`, `img`, `author`, `tags`,`userid`) VALUES ('$cat','$titel', '$body','$unique_image', '$author', '$tags', '$userid') ";
            $inserted_rows = $db->insert($query);
            if ($inserted_rows) {
                echo "<span class='success'>Post Inserted Successfully.
                </span>";
            }else {
                echo "<span class='error'>Post Not Inserted !</span>";
            }
        }
 }    
 ?>                
                <div class="block">               
                 <form action="" method="POST" enctype="multipart/form-data">
                    <table class="form">
                       
                        <tr>
                            <td>
                                <label>Title</label>
                            </td>
                            <td>
                                <input name="titel" type="text" placeholder="Enter Post Title..." class="medium" />
                            </td>
                        </tr>
                     
                        <tr>
                            <td>
                                <label>Category</label>
                            </td>
                            <td>
                                <select id="select" name="cat">
                                    <option value="1">Category Select</option>
<?php 
    $query = "SELECT * FROM `tbl_cat`";
    $catagory = $db->select($query);
    if($catagory){
        while($result = $catagory->fetch_assoc()){
?>                                    
                                    <option value="<?= $result['id']; ?>"><?= $result['name']; ?></option>
<?php } } ?>                                    
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label>Upload Image</label>
                            </td>
                            <td>
                                <input type="file" name="img" />
                            </td>
                        </tr>
                        <tr>
                            <td style="vertical-align: top; padding-top: 9px;">
                                <label>Content</label>
                            </td>
                            <td>
                            <textarea rows="10" cols="70" class="tinymce" name="body">
                                </textarea>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label>Tags</label>
                            </td>
                            <td>
                                <input type="text" id="" name="tags" />
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label>Author</label>
                            </td>
                            <td>
                                <input type="text" id="" name="author" value="<?= Session::get('username'); ?>" />
                                <input type="hidden" id="" name="userid" value="<?= Session::get('userid'); ?>" />
                            </td>
                        </tr>
						<tr>
                            <td></td>
                            <td>
                                <input type="submit" name="submit" Value="Save" />
                            </td>
                        </tr>
                    </table>
                    </form>
                </div>
            </div>
        </div>
 <?php require 'inc/footer.php'; ?>