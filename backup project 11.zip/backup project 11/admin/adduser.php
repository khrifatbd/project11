<?php require 'inc/header.php'; ?>
<?php require 'inc/sidebar.php'; ?>
        <div class="grid_10">
        <?php
            if(!Session::get('userRole') == '0'){
              echo "<script>window.location ='index.php' </script>";} 
          ?>
            <div class="box round first grid">
                <h2>Add New User.</h2>
               <div class="block copyblock">   
 <?php
if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $username = $fm->validation($_POST['username']);
    $email = $fm->validation($_POST['email']);
    $password = $fm->validation(md5($_POST['password']));
    $role = $fm->validation($_POST['role']);

    if(empty($username)){
        echo "<span style='color:red'>Username not be empty </span>";
    }elseif(empty($email)){
        echo "<span style='color:red'>Email not be empty </span>";
    }elseif(empty($password)){
        echo "<span style='color:red'>Password not be empty </span>";
    }else{
        $email_query = "SELECT * FROM `tbl_user` WHERE `email` = '$email' LIMIT 1";
        $email_cheak = $db->select($email_query);
        if($email_cheak != false){
            echo "<span style='color:red'>Email allready exits. </span>";
        }else{
            $query = "INSERT INTO `tbl_user`( `username`, `password`,`email`,  `role`) VALUES ('$username', '$password', '$email', '$role')";
            $catInsart = $db->insert($query);
            if($catInsart){
                echo "<span style='color:green'>User created successfully. </span>";
            }else{
                echo "<span style='color:red'>something worng! </span>";
            }
        }    
    }
 }
 ?>
                 <form action="" method="POST">
                    <table class="form">					
                        <tr>
                            <td>
                                <label for="username">Username</label>
                            </td>
                            <td>
                                <input type="text" name= "username" placeholder="Enter User Name..." class="medium" />
                            </td>
                        </tr>						
                        <tr>
                            <td>
                                <label for="email">Email</label>
                            </td>
                            <td>
                                <input type="email" name= "email" placeholder="Enter Email address..." class="medium" />
                            </td>
                        </tr>	
                        <tr>
                            <td>
                                <label for="password">Password</label>
                            </td>
                            <td>
                                <input type="text" name= "password" placeholder="Enter User password..." class="medium" />
                            </td>
                        </tr>		
                        <tr>
                            <td>
                                <label for="role">Role</label>
                            </td>
                            <td>
                              <select name="role" id="select">
                                  <option value="">Select User</option>
                                  <option value="0">Admin</option>
                                  <option value="1">Author</option>
                                  <option value="2">Editor</option>
                              </select>
                            </td>
                        </tr>
						<tr> 
                            <td></td>
                            <td>
                                <input type="submit" name="submit" Value="Create" />
                            </td>
                        </tr>
                    </table>
                    </form>
                </div>
            </div>
<?php require 'inc/footer.php'; ?>