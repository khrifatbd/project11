﻿<?php require 'inc/header.php'; ?>
<?php require 'inc/sidebar.php'; ?>
        <div class="grid_10">
		
            <div class="box round first grid">
                <h2>Add New Category</h2>
               <div class="block copyblock">   
 <?php
 if(isset($_POST['submit'])){
    $catname =  $_POST['name'];
    if(empty($catname)){
        echo "<span style='color:red'>field most not be empty </span>";
    }else{
        $query = "INSERT INTO `tbl_cat`(`name`) VALUES ('$catname')";
        $catInsart = $db->insert($query);
        if($catInsart){
            echo "<span style='color:green'>Catagory inserted succesfully. </span>";
        }else{
            echo "<span style='color:red'>something worng! </span>";
        }
    }
 }
 ?>
                 <form action="" method="POST">
                    <table class="form">					
                        <tr>
                            <td>
                                <input type="text" name= "name" placeholder="Enter Category Name..." class="medium" />
                            </td>
                        </tr>
						<tr> 
                            <td>
                                <input type="submit" name="submit" Value="Save" />
                            </td>
                        </tr>
                    </table>
                    </form>
                </div>
            </div>
<?php require 'inc/footer.php'; ?>