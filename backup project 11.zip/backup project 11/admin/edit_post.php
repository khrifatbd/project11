<?php require 'inc/header.php'; ?>
<?php require 'inc/sidebar.php'; ?>
        <div class="grid_10">
            <div class="box round first grid">
                <h2>Update Post</h2>
<?php 
    if(isset($_GET['edit_post_id'])){
        $edit_id = $_GET['edit_post_id'];
    }
?>               
<?php
 if(isset($_POST['update'])){
    $titel = $_POST['titel'];
    $cat = $_POST['cat'];
    $body = $_POST['body'];
    $tags = $_POST['tags'];
    $author = $_POST['author'];
    $userid = $_POST['userid'];

    $permited  = array('jpg', 'jpeg', 'png', 'gif');
    $file_name = $_FILES['img']['name'];
    $file_size = $_FILES['img']['size'];
    $file_temp = $_FILES['img']['tmp_name'];

    $div = explode('.', $file_name);
    $file_ext = strtolower(end($div));
    $unique_image = substr(md5(time()), 0, 10).'.'.$file_ext;
    $uploaded_image = "upload/".$unique_image;
    if(empty($tags)){
        echo "<span style='color:red'>field most not be empty </span>";
    }else{
        $post_query = "UPDATE `tbl_post` SET `cat`='$cat',`titel`='$titel',`body`='$body',`img`='$unique_image',`author`='$author',`tags`='$tags',`userid`='$userid' WHERE `id` = '$edit_id'";
        $update_post = $db->update($post_query);
        if($update_post){
            move_uploaded_file($file_temp, $uploaded_image);
        }
    }

       
}    
 ?>                
                <div class="block">    
<?php
    $query = "SELECT * FROM `tbl_post` WHERE `id` = '$edit_id'";
    $get_post = $db->select($query);
    if($get_post){
        while($post_result = $get_post->fetch_assoc()){
?>                               
                 <form action="" method="POST" enctype="multipart/form-data">
                    <table class="form">
                       
                        <tr>
                            <td>
                                <label>Title</label>
                            </td>
                            <td>
                                <input name="titel" type="text" value="<?= $post_result['titel']; ?>" class="medium" />
                            </td>
                        </tr>
                     
                        <tr>
                            <td>
                                <label>Category</label>
                            </td>
                            <td>
                                <select id="select" name="cat">
                                    <option value="1">Category Select</option>
<?php 
    $query = "SELECT * FROM `tbl_cat`";
    $catagory = $db->select($query);
    if($catagory){
        while($result = $catagory->fetch_assoc()){
?>                                    
                                    <option value="<?= $result['id']; ?>"><?= $result['name']; ?></option>
<?php } } ?>                                    
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label>Upload Image</label>
                            </td>
                            <td>
                                <img src="upload/<?= $post_result['img']; ?>" alt="img" width="200px" height="150px"><br>
                                <input type="file" name="img" />
                            </td>
                        </tr>
                        <tr>
                            <td style="vertical-align: top; padding-top: 9px;">
                                <label>Content</label>
                            </td>
                            <td>
                                <textarea rows="10" cols="70" class="tinymce" name="body">
                                    <?= $post_result['body']; ?>
                                </textarea>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label>Tags</label>
                            </td>
                            <td>
                                <input type="text" id="" name="tags" value="<?= $post_result['tags']; ?>"/>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label>Author</label>
                            </td>
                            <td>
                                <input type="text" id="" name="author" value="<?= Session::get('username'); ?>" />
                                <input type="hidden"  id="" name="userid" value="<?= Session::get('userid'); ?>" />
                            </td>
                        </tr>
						<tr>
                            <td></td>
                            <td>
                                <input type="submit" name="update" Value="Update" />
                            </td>
                        </tr>
                    </table>
                    </form>
<?php } } ?>                    
                </div>
            </div>
        </div>
 <?php require 'inc/footer.php'; ?>