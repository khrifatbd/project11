
<?php include '../lib/Session.php'; 
Session::init();
?>
<?php include '../config/config.php'; ?>
<?php include '../lib/Database.php'; ?>
<?php include '../helpers/Format.php'; ?>
<?php
	$db = new Database();
	$fm = new Format();
?>
<!DOCTYPE html>
<head>
<meta charset="utf-8">
<title>Password recover</title>
    <link rel="stylesheet" type="text/css" href="css/stylelogin.css" media="screen" />
</head>
<body>
<div class="container">
	<section id="content">
		<form action="" method="post">
<?php
	if($_SERVER['REQUEST_METHOD'] == 'POST'){
		$email = $fm->validation($_POST['email']);
        if(empty($email)){
			echo $error = "Email is not empty!";
		}elseif(!filter_var($email, FILTER_VALIDATE_EMAIL)){
			echo $error = "invailed email!";
		}else{
            $email_query = "SELECT * FROM `tbl_user` WHERE `email` = '$email' LIMIT 1";
            $email_cheak = $db->select($email_query);
            if($email_cheak != false){
                while($value = $email_cheak->fetch_assoc()){
                    $userid = $value['id'];
                    $username = $value['username'];
                }
            }else{
                echo "<span style='color:red'>doesnot found!</span>";
            }
        }

	}
?>
			<h1>Password Recover.</h1>
			<div>
				<input type="text" placeholder="Enter your Email"  name="email"/>
			</div>
			<div>
				<input type="submit" value="Send EMail" name="send" />
			</div>
		</form><!-- form -->
		<div class="button">
			<a href="login.php">Log In</a>
		</div><!-- button -->
		<div class="button">
			<a href="#">Training with live project</a>
		</div><!-- button -->
	</section><!--  
echo "<script>window.location ='index.php' </script>"; content -->
</div><!-- container -->
</body>
</html>
