<?php require 'inc/header.php'; ?>
<?php require 'inc/sidebar.php'; ?>
        <div class="grid_10">
<?php
    $userid = Session::get('userid');
    $userrole= Session::get('userRole');
?>
            <div class="box round first grid">
                <h2>Update Profile</h2>             
<?php
 if(isset($_POST['update'])){
    $name = $fm->validation($_POST['name']);
    $username = $fm->validation($_POST['username']);
    $email = $fm->validation($_POST['email']);
    $details = $fm->validation($_POST['details']);

    if(empty($name)){
        echo "<span style='color:red'>name not be empty </span>";
    }elseif(empty($username)){
        echo "<span style='color:red'>USername not be empty </span>";
    }elseif(empty($email)){
        echo "<span style='color:red'>Email not be empty </span>";
    }elseif(empty($details)){
        echo "<span style='color:red'>Details not be empty </span>";
    }else{
        $query = "UPDATE `tbl_user` SET `name`='$name',`username`='$username',`email`='$email',`details`='$details' WHERE `id` = '$userid'";
        $catInsart = $db->update($query);
        if($catInsart){
            echo "<span style='color:green'>User Update successfully. </span>";
        }else{
            echo "<span style='color:red'>something worng! </span>";
        }
    }
        
    }

       
    
 ?>                
                <div class="block">    
<?php
    $query = "SELECT * FROM `tbl_user` WHERE `id` = '$userid'";
    $get_user = $db->select($query);
    if($get_user){
        while($post_result = $get_user->fetch_assoc()){
?>                               
                 <form action="" method="POST" enctype="multipart/form-data">
                    <table class="form">
                       
                        <tr>
                            <td>
                                <label>Name</label>
                            </td>
                            <td>
                                <input name="name" type="text" value="<?= $post_result['name']; ?>" class="medium" />
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label>Username</label>
                            </td>
                            <td>
                                <input name="username" type="text" value="<?= $post_result['username']; ?>" class="medium" />
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label>Email</label>
                            </td>
                            <td>
                                <input name="email" type="text" value="<?= $post_result['email']; ?>" class="medium" />
                            </td>
                        </tr>
                        <tr>
                            <td style="vertical-align: top; padding-top: 9px;">
                                <label>Details</label>
                            </td>
                            <td>
                                <textarea rows="10" cols="70" class="tinymce" name="details">
                                    <?= $post_result['details']; ?>
                                </textarea>
                            </td>
                        </tr>
                        <tr>
                            <td></td>
                            <td>
                                <input type="submit" name="update" Value="Update" />
                            </td>
                        </tr>
                    </table>
                    </form>
<?php } } ?>                    
                </div>
            </div>
        </div>
 <?php require 'inc/footer.php'; ?>