<?php require 'inc/header.php'; ?>
<?php require 'inc/sidebar.php'; ?>
        <div class="grid_10">
            <div class="box round first grid">
                <h2>User List.</h2>
<?php
	if(isset($_GET['deluser'])){
		$deluser = $_GET['deluser'];
		$del_queary = "DELETE FROM `tbl_user` WHERE `id` ='$deluser'";
		$delete_data = $db->delete($del_queary);
		if($delete_data){
			echo "<span style='color:green'>catagory delete succesfully.</span>";
		}else{
			echo "<span style='color:red'>catagory no deleted.</span>";
		}
	}
?>
                <div class="block">        
                    <table class="data display datatable" id="example">
					<thead>
						<tr>
							<th>Serial No.</th>
							<th> Name</th>
							<th>UserName</th>
							<th>Email</th>
							<th>Details</th>
							<th>Role</th>
							<th>Action</th>
						</tr>
					</thead>
					<tbody>
<?php
	$query = "SELECT * FROM `tbl_user` ";
	$catagory = $db->select($query);
	if($catagory){
		$i = 0;
		while ($result = $catagory->fetch_assoc()){
			$i++;
?>
						<tr class="odd gradeX">
							<td width="5%" ><?= $i; ?></td>
							<td width="10%"><?= strtoupper($result['name']); ?></td>
							<td width="10%"><?= strtoupper($result['username']); ?></td>
							<td width="10%"><?= strtoupper($result['email']); ?></td>
							<td width="15%"><?= $fm->textShot(strtoupper($result['details']), 30); ?></td>
							<td width="5%"><?php
                                if($result['role']==0){
                                    echo "Admin";
                                }elseif($result['role']==1){
                                    echo "author";
                                }else{
                                    echo "editor";
                                }
                            ?></td>
							<td width="10%"><a href="viewuser.php?viewid=<?= $result['id'];?>">View</a> 
			<?php
                    if(Session::get('userRole') == '0'){ ?>
						<a onclick= "return confirm('Are you sure to delete?')" href="?deluser=<?= $result['id'];?>"> || Delete</a><?php } ?>
						</td>
						</tr>
<?php } } ?>						
					</tbody>
				</table>
               </div>
            </div>
        </div>
		<div class="clear">
        </div>
    </div>
    <div class="clear">
    </div>
	<script type="text/javascript">
        $(document).ready(function () {
            setupLeftMenu();
            $('.datatable').dataTable();
			setSidebarHeight();
        });
    </script>
    <div id="site_info">
      <p>
         &copy; Copyright <a href="http://trainingwithliveproject.com">Training with live project</a>. All Rights Reserved.
        </p>
    </div>
	   
</body>
</html>

