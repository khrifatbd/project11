<?php require 'inc/header.php'; ?>
<?php require 'inc/sidebar.php'; ?>
        <div class="grid_10">
            <div class="box round first grid">
                <h2>View Massage</h2>
<?php
 if(isset($_GET['viewid'])){
   $msgid = $_GET['viewid'];
 }   
 ?>                
                <div class="block">   
 <?php
	$query = "SELECT * FROM `tbl_contact` WHERE `id` = '$msgid';";
	$msg = $db->select($query);
	if($msg){
		$i = 0;
		while ($result = $msg->fetch_assoc()){
			$i++;
?>               
                 <form action="" method="POST" enctype="multipart/form-data">
                    <table class="form">
                       
                        <tr>
                            <td>
                                <label>Name</label>
                            </td>
                            <td>
                                <input name="name" type="text" value="<?= $result['firstname'].' '.$result['lastname']; ?>" readonly class="medium" />
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label>Date</label>
                            </td>
                            <td>
                                <input name="email" type="text" value="<?= $fm->formatDate($result['date']); ?>" readonly class="medium" />
                            </td>
                        <tr>
                        <tr>
                            <td>
                                <label>Email</label>
                            </td>
                            <td>
                                <input name="email" type="text" value="<?= $result['email']; ?>" readonly class="medium" />
                            </td>
                        <tr>
                            <td style="vertical-align: top; padding-top: 9px;">
                                <label>Massage</label>
                            </td>
                            <td>
                            <textarea rows="10" cols="70" class="tinymce" name="body" readonly>
                           <?= $result['bdoy']; ?> 
                                </textarea>
                            </td>
                        </tr>
						<tr>
                            <td></td>
                            <td>
<?php
if(isset($_POST['ok'])){
    echo "<script>window.location = 'in.php'; </script> ";
}
?>
                                <input type="submit" name="ok" Value="OK" />
                            </td>
                        </tr>
                    </table>
                    </form>
<?php }} ?>                    
                </div>
            </div>
        </div>
 <?php require 'inc/footer.php'; ?>