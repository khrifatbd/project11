﻿<?php require 'inc/header.php'; ?>
<?php require 'inc/sidebar.php'; ?>
        <div class="grid_10">
            <div class="box round first grid">
                <h2>Inbox</h2>
<?php
 if(isset($_GET['seenid'])){
    $seenid =  $_GET['seenid'];
        $query = "UPDATE `tbl_contact` SET `stutas`='1' WHERE `id` = '$seenid'";
        $catInsart = $db->update($query);
        if($catInsart){
            echo "<span style='color:green'>Massage send SeenBox. </span>";
        }else{
            echo "<span style='color:red'>something worng! </span>";
        }
    }
 ?>
 <?php
	 if(isset($_GET['delid'])){
		 $delid = $_GET['delid'];
		 $query = "DELETE FROM `tbl_contact` WHERE `id` = '$delid'";
		 $catInsart = $db->delete($query);
		 if($catInsart){
			 echo "<span style='color:green'>Massage deleted successfully. </span>";
		 }else{
			 echo "<span style='color:red'>something worng! </span>";
		 }
	 }
 ?>
                <div class="block">        
                    <table class="data display datatable" id="example">
					<thead>
						<tr class="odd gradeX">
							<th>Serial No.</th>
							<th>Name</th>
							<th>Email</th>
							<th>Message</th>
							<th>Date</th>
							<th>Action</th>
						</tr>
					</thead>
					<tbody>
<?php
	$query = "SELECT * FROM `tbl_contact` WHERE stutas= '0' ORDER BY id DESC ";
	$msg = $db->select($query);
	if($msg){
		$i = 0;
		while ($result = $msg->fetch_assoc()){
			$i++;
?>
						<tr class="odd gradeX">
							<td><?= $i ?></td>
							<td><?= ucwords($result['firstname']).' '.$result['lastname']; ?></td>
							<td><?= ucwords($result['email']); ?></td>
							<td><?= $fm->textShot(ucwords($result['bdoy']),30); ?></td>
							<td><?= $fm->formatDate($result['email']); ?></td>
							<td>
								<a href="viewmsg.php?viewid=<?= $result['id']?> ">View</a> || 
								<a href="replymsg.php?replyid=<?= $result['id']?> ">Reply</a> || 
								<a  onclick= "return confirm('Are you sure to msg seen box?')" href="?seenid=<?= $result['id']?> ">Seen</a> || 
							</td>
						</tr>
<?php }} ?>						
					</tbody>
				</table>
               </div>
            </div>
<!-- seeen msg --------------------->

            <div class="box round first grid">
                <h2>Seen Massage</h2>
                <div class="block">        
                           
				<table class="data display datatable" id="example">
					<thead>
						<tr class="odd gradeX">
							<th>Serial No.</th>
							<th>Name</th>
							<th>Email</th>
							<th>Message</th>
							<th>Date</th>
							<th>Action</th>
						</tr>
					</thead>
					<tbody>
<?php
	$query = "SELECT * FROM `tbl_contact` WHERE stutas= '1' ORDER BY id DESC ";
	$msg = $db->select($query);
	if($msg){
		$i = 0;
		while ($result = $msg->fetch_assoc()){
			$i++;
?>
						<tr class="odd gradeX">
							<td><?= $i ?></td>
							<td><?= ucwords($result['firstname']).' '.$result['lastname']; ?></td>
							<td><?= ucwords($result['email']); ?></td>
							<td><?= $fm->textShot(ucwords($result['bdoy']),30); ?></td>
							<td><?= $fm->formatDate($result['email']); ?></td>
							<td>
								<a href="viewmsg.php?viewid=<?= $result['id']?> ">View</a> || 
								<a  onclick= "return confirm('Are you sure to delete?')" href="?delid=<?= $result['id']?> ">Delete</a> 
							</td>
						</tr>
<?php }} ?>						
					</tbody>
				</table>
               </div>
            </div>
        </div>
		
	<script type="text/javascript">
        $(document).ready(function () {
            setupLeftMenu();
            $('.datatable').dataTable();
			setSidebarHeight();
        });
    </script>
<?php require 'inc/footer.php'; ?>