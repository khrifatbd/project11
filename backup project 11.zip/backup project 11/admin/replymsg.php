<?php require 'inc/header.php'; ?>
<?php require 'inc/sidebar.php'; ?>
        <div class="grid_10">
            <div class="box round first grid">
                <h2>View Massage</h2>
<?php
    if($_SERVER['REQUEST_METHOD'] == 'POST'){
		$toemail = $fm->validation($_POST['toemail']);
		$fromemail = $fm->validation($_POST['fromemail']);
		$subject = $fm->validation($_POST['subject']);
		$body = $fm->validation($_POST['body']);

        $send = mail($toemail,$subject,$body,$fromemail);
        if($send){
            echo "<span class='success'>Email send successfully.</span>";
        }else{
            echo "<span class='error'>Email does not send.</span>";
        }

    }    
?>
 <?php
    if(isset($_GET['replyid'])){
        $replyid = $_GET['replyid'];
    }
 ?>
<?php
	$query = "SELECT * FROM `tbl_contact` WHERE `id` = '$replyid';";
	$msg = $db->select($query);
	if($msg){
		while ($result = $msg->fetch_assoc()){
?>               
                 <form action="" method="POST" enctype="multipart/form-data">
                    <table class="form">
                        <tr>
                            <td>
                                <label>To</label>
                            </td>
                            <td>
                                <input name="toemail" type="text" value="<?= $result['email'] ?>" readonly  class="medium" />
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label>From</label>
                            </td>
                            <td>
                                <input name="fromemail" type="text"   class="medium" />
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label>Subject</label>
                            </td>
                            <td>
                                <input name="subject" type="text" class="medium" />
                            </td>
                        </tr>
                            <td style="vertical-align: top; padding-top: 9px;">
                                <label>Massage</label>
                            </td>
                            <td>
                            <textarea rows="10" cols="70" class="tinymce" name="body" >
                                </textarea>
                            </td>
                        </tr>
						<tr>
                            <td></td>
                            <td>
<?php
if(isset($_POST['ok'])){
    echo "<script>window.location = 'in.php'; </script> ";
}
?>
                                <input type="submit" name="send" Value="Send" />
                            </td>
                        </tr>
                    </table>
                    </form>
<?php }} ?>                    
                </div>
            </div>
        </div>
 <?php require 'inc/footer.php'; ?>