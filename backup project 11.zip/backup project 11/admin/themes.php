<?php require 'inc/header.php'; ?>
<?php require 'inc/sidebar.php'; ?>
        <div class="grid_10">
            <div class="box round first grid">
                <h2>Update Category</h2>
               <div class="block copyblock">   
 <?php
 if(isset($_POST['change'])){
    $theme =  $_POST['theme'];
        $query = "UPDATE `tbl_theme` SET `theme`='$theme' WHERE `id` = '1'";
        $catInsart = $db->update($query);
        if($catInsart){
            echo "<span style='color:green'>Themes updated succesfully. </span>";
        }else{
            echo "<span style='color:red'>something worng! </span>";
        }
 }
 ?>
 <?php 
    $query = "SELECT * FROM `tbl_theme` WHERE `id` = '1'";
    $themes = $db->select($query);
    while($result = $themes->fetch_assoc()){ 
 ?>
                 <form action="" method="POST">
                    <table class="form">					
                        <tr>
                            <td>
                                <input <?php if($result['theme'] == 'defult'){echo 'checked';} ?> type="radio" name="theme" value="defult">Defult
                            </td>
                        </tr>					
                        <tr>
                            <td>
                                <input <?php if($result['theme'] == 'green'){echo 'checked';} ?> type="radio" name="theme" value="green">Green
                            </td>
                        </tr>					
                        <tr>
                            <td>
                                <input <?php if($result['theme'] == 'blue'){echo 'checked';} ?> type="radio" name="theme" value="blue">Blue
                            </td>
                        </tr>
						<tr> 
                            <td>
                                <input type="submit" name="change" Value="Change" />
                            </td>
                        </tr>
                    </table>
                    </form>
<?php } ?>                    
                </div>
            </div>
<?php require 'inc/footer.php'; ?>