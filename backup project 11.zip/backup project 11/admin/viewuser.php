<?php require 'inc/header.php'; ?>
<?php require 'inc/sidebar.php'; ?>
        <div class="grid_10">
<?php
    $userid = Session::get('userid');
    $userrole= Session::get('userRole');
?>
            <div class="box round first grid">
                <h2>User Profile</h2>             
              
                <div class="block">    
<?php
    if(isset($_GET['viewid'])){
        $viewid = $_GET['viewid'];
    }
    $query = "SELECT * FROM `tbl_user` WHERE `id` = '$viewid'";
    $get_user = $db->select($query);
    if($get_user){
        while($post_result = $get_user->fetch_assoc()){
?>                               
                 <form action="" method="POST" ">
                    <table class="form">
                       
                        <tr>
                            <td>
                                <label>Name</label>
                            </td>
                            <td>
                                <input readonly name="name" type="text" value="<?= $post_result['name']; ?>" class="medium" />
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label>Username</label>
                            </td>
                            <td>
                                <input readonly name="username" type="text" value="<?= $post_result['username']; ?>" class="medium" />
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label>Email</label>
                            </td>
                            <td>
                                <input readonly name="email" type="text" value="<?= $post_result['email']; ?>" class="medium" />
                            </td>
                        </tr>
                        <tr>
                            <td style="vertical-align: top; padding-top: 9px;">
                                <label>Details</label>
                            </td>
                            <td>
                                <textarea readonly rows="10" cols="70" class="tinymce" name="details">
                                    <?= $post_result['details']; ?>
                                </textarea>
                            </td>
                        </tr>
                        <tr>
                            <td></td>
<?php
    if(isset($_POST['ok'])){
        
    }
?>
                            <td>
                                <input type="submit" name="ok" Value="ok" />
                            </td>
                        </tr>
                    </table>
                    </form>
<?php } } ?>                    
                </div>
            </div>
        </div>
 <?php require 'inc/footer.php'; ?>