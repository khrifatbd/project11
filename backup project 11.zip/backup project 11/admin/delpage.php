
<?php include '../config/config.php'; ?>
<?php include '../lib/Database.php'; ?>
<?php include '../helpers/Format.php'; ?>
<?php
	$db = new Database();
	$fm = new Format();
?>

<?php 
    if(isset($_GET['delpage'])){
        $id = $_GET['delpage'];

        $query = "DELETE FROM `tbl_page`  WHERE `id` = '$id'";
        $deldata = $db->delete($query);
        if($deldata){
            echo "<script>alert('Data deleted succesfully!') ;</script>";
            header('location:index.php');
        }else{
            echo "<script>alert('Data does not deleted!') ;</script>";
             header('location:page.php.php');
        }
    }
    

?>  
