<?php require 'inc/header.php'; ?>
<?php require 'inc/sidebar.php'; ?>
        <div class="grid_10">
            <div class="box round first grid">
   <style>
       .actiondel{margin-left:10px; }
       .actiondel a{border:1px solid #ddd; color: #444;padding: 7px;}
       .actiondel a:hover{background:#888; color:#f1f1f1} 
   </style>
            <h2>Add New Post</h2>
<?php
    if(isset($_GET['pageid'])){
        $pageid = $_GET['pageid'];
    }else{
        echo "page not found";
    }
?>
<?php
 if(isset($_POST['submit'])){
    $name = trim($_POST['name']);
    $titel = trim($_POST['titel']);
    $body = trim($_POST['body']);

    $permited  = array('jpg', 'jpeg', 'png', 'gif');
    $file_name = $_FILES['img']['name'];
    $file_size = $_FILES['img']['size'];
    $file_temp = $_FILES['img']['tmp_name'];

    $div = explode('.', $file_name);
    $file_ext = strtolower(end($div));
    $unique_image = substr(md5(time()), 0, 10).'.'.$file_ext;
    $uploaded_image = "upload/".$unique_image;

    if (empty($name) || empty($titel) || empty($body) ) {
        echo "<span class='error'>Filed must not be empty!</span>";
       }elseif ($file_size >1048567) {
        echo "<span class='error'>Image Size should be less then 1MB!
        </span>";
       } elseif (in_array($file_ext, $permited) === false) {
        echo "<span class='error'>You can upload only:-".implode(', ', $permited)."</span>";
       } else{
            move_uploaded_file($file_temp, $uploaded_image);
            $query = "UPDATE `tbl_page` SET `name`='$name',`titel`='$titel',`img`='$unique_image',`body`='$body' WHERE `id`='$pageid'";
            $inserted_rows = $db->update($query);
            if ($inserted_rows) {
                echo "<span class='success'>Page Update Successfully.
                </span>";
            }else {
                echo "<span class='error'>Page Not updated !</span>";
            }
        }
 }    
 ?>                
                <div class="block">    
<?php 
     $query = "SELECT * FROM `tbl_page` where id= '$pageid'";
     $page = $db->select($query);
     if($page){
         while($pagename = $page->fetch_assoc()){ 
 ?>                                
                 <form action="" method="POST" enctype="multipart/form-data">
                    <table class="form">
                        <tr>
                            <td>
                                <label>Name</label>
                            </td>
                            <td>
                                <input name="name" type="text" value="<?= $pagename['name']; ?>" class="medium" />
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label>Title</label>
                            </td>
                            <td>
                                <input name="titel" type="text" value="<?= $pagename['titel']; ?>" class="medium" />
                            </td>
                        </tr>
                            <td>
                                <label>Upload Image</label>
                            </td>
                            <td>
                                <input type="file" name="img" />
                            </td>
                        </tr>
                        <tr>
                            <td style="vertical-align: top; padding-top: 9px;">
                                <label>Content</label>
                            </td>
                            <td>
                            <textarea rows="10" cols="70" class="tinymce" name="body">
                            <?= $pagename['body']; ?>
                                </textarea>
                            </td>
                        </tr>
						<tr>
                            <td></td>
                            <td>
                                <input type="submit" name="submit" Value="Update" />
                                <span class="actiondel">
                                    <a onclick= "return confirm('Are you sure to delete?')" href="delpage.php?delpage=<?= $pageid ?>">Delete</a>
                                </span>
                            </td>
                        </tr>                 
                    </table>
                    </form>
<?php } } ?>  
                </div>
            </div>
        </div>
 <?php require 'inc/footer.php'; ?>