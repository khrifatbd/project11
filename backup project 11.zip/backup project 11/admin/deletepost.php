
<?php include '../config/config.php'; ?>
<?php include '../lib/Database.php'; ?>
<?php include '../helpers/Format.php'; ?>
<?php
	$db = new Database();
	$fm = new Format();
?>

<?php 
    if(isset($_GET['del_post_id'])){
        $id = $_GET['del_post_id'];

        $query = "DELETE FROM `tbl_post` WHERE `id` = '$id'";
        $deldata = $db->delete($query);
        if($deldata){
            echo "<script>alert('Data deleted succesfully!') ;</script>";
            header('location:postlist.php');
        }else{
            echo "<script>alert('Data does not deleted!') ;</script>";
             header('location:postlist.php');
        }
    }
    

?>  
