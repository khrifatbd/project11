﻿<?php require 'inc/header.php'; ?>
<?php require 'inc/sidebar.php'; ?>
        <div class="grid_10">
            <div class="box round first grid">
                <h2>Category List</h2>
<?php
	if(isset($_GET['delcat'])){
		$delid = $_GET['delcat'];
		$del_queary = "DELETE FROM `tbl_cat` WHERE `id` ='$delid'";
		$delete_data = $db->delete($del_queary);
		if($delete_data){
			echo "<span style='color:green'>catagory delete succesfully.</span>";
		}else{
			echo "<span style='color:red'>catagory no deleted.</span>";
		}
	}
?>
                <div class="block">        
                    <table class="data display datatable" id="example">
					<thead>
						<tr>
							<th>Serial No.</th>
							<th>Category Name</th>
							<th>Action</th>
						</tr>
					</thead>
					<tbody>
<?php
	$query = "SELECT * FROM `tbl_cat` ORDER by id DESC ";
	$catagory = $db->select($query);
	if($catagory){
		$i = 0;
		while ($result = $catagory->fetch_assoc()){
			$i++;
?>
						<tr class="odd gradeX">
							<td><?= $i; ?></td>
							<td><?= strtoupper($result['name']); ?></td>
							<td><a href="editcat.php?catid=<?= $result['id'];?>">Edit</a> || <a onclick= "return confirm('Are you sure to delete?')" href="?delcat=<?= $result['id'];?>">Delete</a></td>
						</tr>
<?php } } ?>						
					</tbody>
				</table>
               </div>
            </div>
        </div>
		<div class="clear">
        </div>
    </div>
    <div class="clear">
    </div>
	<script type="text/javascript">
        $(document).ready(function () {
            setupLeftMenu();
            $('.datatable').dataTable();
			setSidebarHeight();
        });
    </script>
    <div id="site_info">
      <p>
         &copy; Copyright <a href="http://trainingwithliveproject.com">Training with live project</a>. All Rights Reserved.
        </p>
    </div>
	   
</body>
</html>

