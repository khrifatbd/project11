﻿<?php require 'inc/header.php'; ?>
<?php require 'inc/sidebar.php'; ?>
        <div class="grid_10">
		
            <div class="box round first grid">
                <h2>Update Copyright Text</h2>
 <?php
 if(isset($_POST['updatecopy'])){
   $note = $_POST['note'];
   
        $copy_right = "UPDATE `tbl_footer` SET `note`='$note' WHERE `id`=1";
        $copy_right = $db->update($copy_right);
        if($copy_right){
            echo "<span class='success'>Copy right updated!</span>";
        }
}   
 ?>  
                <div class="block copyblock"> 
<?php
     $query = "SELECT * FROM `tbl_footer` WHERE `id` = 1";
     $footer = $db->select($query);
     if($footer){
         while($result = $footer->fetch_assoc()){ 
 ?> 
                 <form action="" method="POST">
                    <table class="form">					
                        <tr>
                            <td>
                                <input type="text" value="<?= $result['note'] ?>" name="note" class="large" />
                            </td>
                        </tr>
						
						 <tr> 
                            <td>
                                <input type="submit" name="updatecopy" Value="Update" />
                            </td>
                        </tr>
                    </table>
                    </form>
<?php }} ?>
                </div>
            </div>
        </div>
<?php require 'inc/footer.php'; ?>
