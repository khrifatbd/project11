<?php require 'inc/header.php'; ?>
<?php require 'inc/sidebar.php'; ?>
        <div class="grid_10">
            <div class="box round first grid">
                <h2>Add New Post</h2>
<?php
 if(isset($_POST['submit'])){
    $name = trim($_POST['name']);
    $titel = trim($_POST['titel']);
    $body = trim($_POST['body']);

    $permited  = array('jpg', 'jpeg', 'png', 'gif');
    $file_name = $_FILES['img']['name'];
    $file_size = $_FILES['img']['size'];
    $file_temp = $_FILES['img']['tmp_name'];

    $div = explode('.', $file_name);
    $file_ext = strtolower(end($div));
    $unique_image = substr(md5(time()), 0, 10).'.'.$file_ext;
    $uploaded_image = "upload/".$unique_image;

    if (empty($name) || empty($titel) || empty($body) ) {
        echo "<span class='error'>Filed must not be empty!</span>";
       }elseif ($file_size >1048567) {
        echo "<span class='error'>Image Size should be less then 1MB!
        </span>";
       } elseif (in_array($file_ext, $permited) === false) {
        echo "<span class='error'>You can upload only:-".implode(', ', $permited)."</span>";
       } else{
            move_uploaded_file($file_temp, $uploaded_image);
            $query = "INSERT INTO `tbl_page`( `name`, `titel`, `img`, `body`) VALUES ('$name','$titel', '$unique_image', '$body')";
            $inserted_rows = $db->insert($query);
            if ($inserted_rows) {
                echo "<span class='success'>Page created Successfully.
                </span>";
            }else {
                echo "<span class='error'>Page not created !</span>";
            }
        }
 }    
 ?>                
                <div class="block">               
                 <form action="" method="POST" enctype="multipart/form-data">
                    <table class="form">
                       
                        <tr>
                            <td>
                                <label>Name</label>
                            </td>
                            <td>
                                <input name="name" type="text" placeholder="Enter Post Title..." class="medium" />
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label>Title</label>
                            </td>
                            <td>
                                <input name="titel" type="text" placeholder="Enter Post Title..." class="medium" />
                            </td>
                        </tr>
                            <td>
                                <label>Upload Image</label>
                            </td>
                            <td>
                                <input type="file" name="img" />
                            </td>
                        </tr>
                        <tr>
                            <td style="vertical-align: top; padding-top: 9px;">
                                <label>Content</label>
                            </td>
                            <td>
                            <textarea rows="10" cols="70" class="tinymce" name="body">
                                </textarea>
                            </td>
                        </tr>
						<tr>
                            <td></td>
                            <td>
                                <input type="submit" name="submit" Value="Creat" />
                            </td>
                        </tr>
                    </table>
                    </form>
                </div>
            </div>
        </div>
 <?php require 'inc/footer.php'; ?>