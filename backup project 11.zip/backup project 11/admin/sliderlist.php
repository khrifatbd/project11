<?php require 'inc/header.php'; ?>
<?php require 'inc/sidebar.php'; ?>
        <div class="grid_10">
            <div class="box round first grid">
                <h2>Slider list</h2>
                <div class="block">  
                    <table class="data display datatable" id="example">
					<thead>
						<tr>
							<th width="5%">NO.</th>
							<th width="15%">Slider Title</th>
							<th width="10%">Slider Image</th>
							<th width="10%">Action</th>
						</tr>
					</thead>
					<tbody>

<?php 
    if(isset($_GET['delslider'])){
        $delslider = $_GET['delslider'];

        $query = "DELETE FROM `tbl_slider` WHERE `id` = '$delslider'";
        $deldata = $db->delete($query);
        if($deldata){
            echo "<script>alert('Slider deleted succesfully!') ;</script>";
        }else{
            echo "<script>alert('Slider does not deleted!') ;</script>";
        }
    }
    

?>                          
<?php
 	$query = "SELECT * FROM `tbl_slider`";
	 $post = $db->select($query);
	 if($post){
		 $i= 0;
		 while ($result = $post->fetch_assoc()){
			 $i++;
?>
						<tr class="odd gradeX">
							<td><?= $i; ?></td>
							<td><?= $result['titel'] ?></td>
							<td><img src="upload/slider/<?= $result['img'] ?>" alt="img" width="150px" height="70px"></td>
                            <?php if(Session::get('userRole') == '0'){ ?>
							    <td><a href="editslider.php?edit_slider_id=<?= $result['id']; ?>">Edit</a> || <a onclick= "return confirm('Are you sure to delete?')" href="?delslider=<?= $result['id']; ?>">Delete</a></td>
                           <?php } ?>
						</tr>
<?php  } }		?>				
					</tbody>
				</table>
	
               </div>
            </div>
        </div>
        <div class="clear">
        </div>
    </div>
    <div class="clear">
    </div>
	<script type="text/javascript">
        $(document).ready(function () {
            setupLeftMenu();
            $('.datatable').dataTable();
			setSidebarHeight();
        });
    </script>
    <div id="site_info">
      <p>
         &copy; Copyright <a href="http://trainingwithliveproject.com">Training with live project</a>. All Rights Reserved.
        </p>
    </div>
	   
</body>
</html>
