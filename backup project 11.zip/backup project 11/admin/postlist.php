﻿<?php require 'inc/header.php'; ?>
<?php require 'inc/sidebar.php'; ?>
        <div class="grid_10">
            <div class="box round first grid">
                <h2>Post List</h2>
                <div class="block">  
                    <table class="data display datatable" id="example">
					<thead>
						<tr>
							<th width="5%">NO.</th>
							<th width="15%">Post Title</th>
							<th width="20%">Description</th>
							<th width="10%">Category</th>
							<th width="10%">Image</th>
							<th width="10%">Author</th>
							<th width="10%">Tags</th>
							<th width="10%">Date</th>
							<th width="10%">Action</th>
						</tr>
					</thead>
					<tbody>
<?php
 	$query = "SELECT tbl_post.* , tbl_cat.name FROM tbl_post INNER JOin tbl_cat ON tbl_post.cat = tbl_cat.id ORDER by tbl_post.titel";
	 $post = $db->select($query);
	 if($post){
		 $i= 0;
		 while ($result = $post->fetch_assoc()){
			 $i++;
?>
						<tr class="odd gradeX">
							<td><?= $i; ?></td>
							<td><?= $result['titel'] ?></td>
							<td><?= $fm->textShot($result['body'], 60); ?></td>
							<td><?= $result['name'] ?></td>
							<td><img src="upload/<?= $result['img'] ?>" alt="img" width="60px" height="50px"></td>
							<td><?= $result['author'] ?></td>
							<td><?= $result['tags'] ?></td>
							<td class="date"> <?= $fm->formatDate($result['date']); ?></td>
							<td><a href="edit_post.php?edit_post_id=<?= $result['id']; ?>">Edit</a> || <a onclick= "return confirm('Are you sure to delete?')" href="deletepost.php?del_post_id=<?= $result['id']; ?>">Delete</a></td>
						</tr>
<?php  } }		?>				
					</tbody>
				</table>
	
               </div>
            </div>
        </div>
        <div class="clear">
        </div>
    </div>
    <div class="clear">
    </div>
	<script type="text/javascript">
        $(document).ready(function () {
            setupLeftMenu();
            $('.datatable').dataTable();
			setSidebarHeight();
        });
    </script>
    <div id="site_info">
      <p>
         &copy; Copyright <a href="http://trainingwithliveproject.com">Training with live project</a>. All Rights Reserved.
        </p>
    </div>
	   
</body>
</html>
