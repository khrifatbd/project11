﻿<?php require 'inc/header.php'; ?>
<?php require 'inc/sidebar.php'; ?>
        <div class="grid_10">
		
            <div class="box round first grid">
                <h2>Update Social Media</h2>
                <div class="block"> 
  <?php
 if(isset($_POST['submit'])){
    $fb = $_POST['fb'];
    $tw = $_POST['tw'];
    $ln = $_POST['ln'];
    $gp = $_POST['gp'];
    if($fb == '' || $tw =="" || $ln == "" || $gp == "" ){
        echo "<span class='error'> Filed must not be empty!</span>";
    }else{
        $social_query = "UPDATE `tbl_social` SET `fb`='$fb',`tw`='$tw',`ln`='$ln',`gp`='$gp' WHERE `id` = 1;";
        $update_social = $db->update($social_query);
        if($update_social){
            echo "<span class='success'> Social update successfully!</span>";
        }
    }    
}   
 ?>              
<?php
     $query = "SELECT * FROM `tbl_social` ";
     $social = $db->select($query);
     if($social){
         while($result = $social->fetch_assoc()){ 
 ?>  
                 <form action="" method="POST">
                    <table class="form">					
                        <tr>
                            <td>
                                <label>Facebook</label>
                            </td>
                            <td>
                                <input type="text" name="fb" value="<?= $result['fb']; ?>" class="medium" />
                            </td>
                        </tr>
						 <tr>
                            <td>
                                <label>Twitter</label>
                            </td>
                            <td>
                                <input type="text" name="tw" value="<?= $result['tw']; ?>" class="medium" />
                            </td>
                        </tr>
						
						 <tr>
                            <td>
                                <label>LinkedIn</label>
                            </td>
                            <td>
                                <input type="text" name="ln" value="<?= $result['ln']; ?>" class="medium" />
                            </td>
                        </tr>
						
						 <tr>
                            <td>
                                <label>Google Plus</label>
                            </td>
                            <td>
                                <input type="text" name="gp" value="<?= $result['gp']; ?>" class="medium" />
                            </td>
                        </tr>
						
						 <tr>
                            <td></td>
                            <td>
                                <input type="submit" name="submit" Value="Update" />
                            </td>
                        </tr>
                    </table>
                    </form>
<?php }} ?>                    
                </div>
            </div>
        </div>
<?php require 'inc/footer.php'; ?>