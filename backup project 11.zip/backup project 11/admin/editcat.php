<?php require 'inc/header.php'; ?>
<?php require 'inc/sidebar.php'; ?>
<?php 
    if(isset($_GET['catid'])){
        $id= $_GET['catid'];
    }
?>
        <div class="grid_10">
            <div class="box round first grid">
                <h2>Update Category</h2>
               <div class="block copyblock">   
 <?php
 if(isset($_POST['update'])){
    $catname =  $_POST['name'];
    if(empty($catname)){
        echo "<span style='color:red'>field most not be empty </span>";
    }else{
        $query = "UPDATE `tbl_cat` SET `name`='$catname' WHERE `id` = '$id'";
        $catInsart = $db->update($query);
        if($catInsart){
            echo "<span style='color:green'>Catagory updated succesfully. </span>";
        }else{
            echo "<span style='color:red'>something worng! </span>";
        }
    }
 }
 ?>
 <?php
    $query = "SELECT * FROM `tbl_cat` WHERE `id` = '$id' ";
    $catagory = $db->select($query);
    while($result = $catagory->fetch_assoc()){
 ?>
                 <form action="" method="POST">
                    <table class="form">					
                        <tr>
                            <td>
                                <input type="text" name= "name" value="<?= $result['name'] ?>" class="medium" />
                            </td>
                        </tr>
						<tr> 
                            <td>
                                <input type="submit" name="update" Value="Update" />
                            </td>
                        </tr>
                    </table>
                    </form>
<?php } ?>                    
                </div>
            </div>
<?php require 'inc/footer.php'; ?>