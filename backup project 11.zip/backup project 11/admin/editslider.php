<?php require 'inc/header.php'; ?>
<?php require 'inc/sidebar.php'; ?>
        <div class="grid_10">
            <div class="box round first grid">
                <h2>Update Post</h2>
<?php 
    if(isset($_GET['edit_slider_id'])){
        $edit_id = $_GET['edit_slider_id'];
    }
?>               
<?php
 if(isset($_POST['update'])){
    $titel = $fm->validation($_POST['titel']); 

    $permited  = array('jpg', 'jpeg', 'png', 'gif');
    $file_name = $_FILES['img']['name'];
    $file_size = $_FILES['img']['size'];
    $file_temp = $_FILES['img']['tmp_name'];

    $div = explode('.', $file_name);
    $file_ext = strtolower(end($div));
    $unique_image = substr(md5(time()), 0, 10).'.'.$file_ext;
    $uploaded_image = "upload/slider/".$unique_image;
    if(empty($titel)){
        echo "<span style='color:red'>field most not be empty </span>";
    }else{
        $post_query = "UPDATE `tbl_slider` SET `titel`='$titel',`img`='$unique_image' WHERE `id`='$edit_id'";
        $update_post = $db->update($post_query);
        if($update_post){
            move_uploaded_file($file_temp, $uploaded_image);
        }
    }

       
}    
 ?>                
                <div class="block">    
<?php
    $query = "SELECT * FROM `tbl_slider` WHERE `id`= $edit_id";
    $get_post = $db->select($query);
    if($get_post){
        while($post_result = $get_post->fetch_assoc()){
?>                               
                 <form action="" method="POST" enctype="multipart/form-data">
                    <table class="form">
                       
                        <tr>
                            <td>
                                <label>Title</label>
                            </td>
                            <td>
                                <input name="titel" type="text" value="<?= $post_result['titel']; ?>" class="medium" />
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label>Upload Image</label>
                            </td>
                            <td>
                                <img src="upload/slider/<?= $post_result['img']; ?>" alt="img" width="200px" height="150px"><br>
                                <input type="file" name="img" />
                            </td>
                        </tr>
						<tr>
                            <td></td>
                            <td>
                                <input type="submit" name="update" Value="Update" />
                            </td>
                        </tr>
                    </table>
                    </form>
<?php } } ?>                    
                </div>
            </div>
        </div>
 <?php require 'inc/footer.php'; ?>