<?php
define("DB_HOST", "localhost");
define("DB_USER", "root");
define("DB_PASS", "");
define("DB_NAME", "db_blog");
define("TITLE", "KH Rifat");
define("KEYWORDS", "KH Rifat, kamrul hasan, Rifat, kh");

