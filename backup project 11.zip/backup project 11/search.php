<?php include 'inc/header.php'; ?>
<?php
 if(!isset($_GET['search']) || $_GET['search'] == NULL){
	header('location: 404.php');
 }else{
	 $search = $_GET['search'];
 }
?>
	<div class="contentsection contemplete clear">
		<div class="maincontent clear">
<?php 
	$query = "SELECT * FROM `tbl_post` WHERE `titel` LIKE '%$search%' or `body` LIKE '%$search%'";
	$post = $db->select($query);
	if($post){
		while($result = $post->fetch_assoc()){
?>
            <div class="samepost clear">
				<h2><a href="post.php?id=<?= $result['id']; ?>"><?= $result['titel']; ?></a></h2>
				<h4><?= $fm->formatDate($result['date']); ?> <a href="#"><?= $result['author']; ?></a></h4>
				 <img src="admin/upload/<?= $result['img'];?>" alt="post image"/>
				<p>	<?= $fm->textShot($result['body']); ?>
				</p>
				<div class="readmore clear">
				<a href="post.php?id=<?= $result['id']; ?>">Read More</a>
				</div>
			</div>
<?php } }else{ ?>
    <p>donot have any search result.</p>
 <?php } ?>

		</div>
<?php require 'inc/sidebar.php';  ?>
<?php require 'inc/footer.php'; ?>   