<?php
class Format{
    public function formatDate($data){
        return date('F j, Y, g:i a',strtotime($data));
    }

    public function textShot($text, $limit = 420){
        $text = $text. " ";
        $text = substr($text, 0, $limit);
        $text = $text.'...';
        return $text;
    }
    public function validation($data){
        $data = trim($data);
        $data = stripcslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }

    public function titel(){
        $path = $_SERVER['SCRIPT_FILENAME'];
        $titel = basename($path,'.php');
        if($titel== 'index'){
            $titel = 'Home';
        }elseif($titel == 'contact'){
            $titel = 'contact';
        }
        return $titel = ucwords($titel);
    }
}


?>