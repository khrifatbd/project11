<?php
		if(isset($_GET['pageid'])){
			$page_titel = $_GET['pageid'];
			$query = "SELECT * FROM `tbl_page` WHERE `id`='$page_titel'";
			$blog_titel = $db->select($query);
			if($blog_titel){
				while($result = $blog_titel->fetch_assoc()){ 
	?>
	<title><?= $result['name']; ?> - <?= TITLE; ?></title>
	<?php
				}
			}
		}elseif(isset($_GET['id'])){
			$post_titel_id = $_GET['id'];
			$query = "SELECT * FROM `tbl_post` WHERE `id`='$post_titel_id'";
			$post_titel = $db->select($query);
			if($post_titel){
				while($result = $post_titel->fetch_assoc()){ 
	?>
	<title><?= $result['titel']; ?> - <?= TITLE; ?></title>
	<?php
				}
			}
		}else{ ?>
	<title><?= $fm->titel(); ?> - <?= TITLE; ?></title>
	<?php	}	?>		
	<meta name="language" content="English">
<?php
	if(isset($_GET['id'])){
		$keyword = $_GET['id'];
		$query = "SELECT * FROM `tbl_post` WHERE `id`='$keyword'";
		$keyword = $db->select($query);
		if($keyword){
			while($result = $keyword->fetch_assoc()){ 
?>
<meta name="description" content="<?= $result['titel'];?>">		
	<meta name="keywords" content="<?= $result['tags'];?>">
<?php
			}
		}else{ ?>
			<meta name="keywords" content="<?echo "KH Rifat, kamrul hasan, Rifat, kh"; ?>">
<?php		}
	}
?>
	<meta name="author" content="Khrifat">