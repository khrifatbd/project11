<?php include 'inc/header.php'; ?>
<?php
 if(!isset($_GET['catgory']) || $_GET['catgory'] == NULL){
	header('location: 404.php');
 }else{
	 $catgory = $_GET['catgory'];
 }
?>
	<div class="contentsection contemplete clear">
		<div class="maincontent clear">
<?php 
	$query = "SELECT * FROM `tbl_post` WHERE `cat` = $catgory";
	$post = $db->select($query);
	if($post){
		while($result = $post->fetch_assoc()){
?>
            <div class="samepost clear">
				<h2><a href="post.php?id=<?= $result['id']; ?>"><?= $result['titel']; ?></a></h2>
				<h4><?= $fm->formatDate($result['date']); ?> <a href="#"><?= $result['author']; ?></a></h4>
				 <img src="admin/upload/<?= $result['img'];?>" alt="post image"/>
				<p>	<?= $fm->textShot($result['body']); ?>
				</p>
				<div class="readmore clear">
				<a href="post.php?id=<?= $result['id']; ?>">Read More</a>
				</div>
			</div>
<?php } }else{
	header('location:404.php');
} ?>

		</div>
<?php require 'inc/sidebar.php';  ?>
<?php require 'inc/footer.php'; ?>   