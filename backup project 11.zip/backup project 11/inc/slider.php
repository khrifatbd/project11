<div class="slidersection templete clear">  
<div id="slider">
<?php
    $query = "SELECT * FROM `tbl_slider` ORDER by id LIMIT 4";
    $get_post = $db->select($query);
    if($get_post){
        while($post_result = $get_post->fetch_assoc()){
?>         
            <a href="#"><img width="960xp" height="300px" src="admin/upload/slider/<?= $post_result['img']; ?>" alt="?= $post_result['titel'] ;?>" title="<?= $post_result['titel'] ;?>" /></a>
<?php }  }?>
        </div>

</div>