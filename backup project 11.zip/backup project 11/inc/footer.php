</div>

<div class="footersection templete clear">
  <div class="footermenu clear">
    <ul>
        <li><a href="#">Home</a></li>
        <li><a href="#">About</a></li>
        <li><a href="#">Contact</a></li>
        <li><a href="#">Privacy</a></li>
    </ul>
  </div>
  <?php
     $query = "SELECT * FROM `tbl_footer` WHERE `id` = 1";
     $footer = $db->select($query);
     if($footer){
         while($copyright = $footer->fetch_assoc()){ 
 ?> 
  <p>&copy;<?= $copyright['note']; ?> <?php echo date('Y'); ?> </p>
  <?php }} ?>
</div>
<?php
     $query = "SELECT * FROM `tbl_social` ";
     $social = $db->select($query);
     if($social){
         while($result = $social->fetch_assoc()){ 
 ?> 
<div class="fixedicon clear">
    <a target=_blank href="<?= $result['fb']; ?>"><img src="images/fb.png" alt="Facebook"/></a>
    <a target=_blank href="<?= $result['tw']; ?>"><img src="images/tw.png" alt="Twitter"/></a>
    <a target=_blank href="<?= $result['ln']; ?>"><img src="images/in.png" alt="LinkedIn"/></a>
    <a target=_blank href="<?= $result['gp']; ?>"><img src="images/gl.png" alt="GooglePlus"/></a>
</div>
<?php }} ?>
<script type="text/javascript" src="js/scrolltop.js"></script>
</body>
</html>