
<?php include 'config/config.php'; ?>
<?php include 'lib/Database.php'; ?>
<?php include 'helpers/Format.php'; ?>
<?php
	$db = new Database();
	$fm = new Format();
?>

<!DOCTYPE html>
<html>
<head>

	<?php include 'script/meta.php'; ?>
	<?php include 'script/css.php'; ?>
	<?php include 'script/js.php'; ?>

</head>
<?php
     $query = "SELECT * FROM `bd_titel_slogan` WHERE `id` = 1";
     $blog_titel = $db->select($query);
     if($blog_titel){
         while($result = $blog_titel->fetch_assoc()){ 
 ?>      
<body>
	<div class="headersection templete clear">
		<a href="index.php">
			<div class="logo">
				<img src="admin/img/logo/<?=$result['logo']; ?>" alt="Logo"/>
				<h2><?= $result['logo_titel']; ?></h2>
				<p><?= $result['slogan']; ?></p>
			</div>
		</a>
<?php }} ?>		
		<div class="social clear">
<?php
     $query = "SELECT * FROM `tbl_social` ";
     $social = $db->select($query);
     if($social){
         while($result = $social->fetch_assoc()){ 
 ?> 			
			<div class="icon clear">
				<a href="<?= $result['fb']; ?>" target="_blank"><i class="fa fa-facebook"></i></a>
				<a href="<?= $result['tw']; ?>" target="_blank"><i class="fa fa-twitter"></i></a>
				<a href="<?= $result['ln']; ?>" target="_blank"><i class="fa fa-linkedin"></i></a>
				<a href="<?= $result['gp']; ?>" target="_blank"><i class="fa fa-google-plus"></i></a>
			</div>
<?php  } } ?>			
			<div class="searchbtn clear">
			<form action="search.php" method="GET">
				<input type="text" name="search" placeholder="Search keyword..."/>
				<input type="submit" name="submit" value="Search"/>
			</form>
			</div>
		</div>
	</div>
<div class="navsection templete">
	<?php
 $path = $_SERVER['SCRIPT_FILENAME'];
 $carrent_page = basename($path,'.php');
	?>
	<ul>
		<li><a <?php if($carrent_page == 'index'){echo 'id="active"';} ?> href="index.php">Home</a></li>
<?php
     $query = "SELECT * FROM `tbl_page` ";
     $page = $db->select($query);
     if($page){
         while($pagename = $page->fetch_assoc()){ 
 ?> 
                                <li><a 
		<?php
			if(isset($_GET['pageid']) && $_GET['pageid'] == $pagename['id']){
				echo 'id="active"';
			}
		?>
								href="page.php?pageid=<?= $pagename['id']; ?>"><?= $pagename['name']; ?></a></li>
 <?php } } ?>       
		<li><a <?php if($carrent_page == 'contact'){echo 'id="active"';} ?> href="contact.php">Contact</a></li>
	</ul>
</div>