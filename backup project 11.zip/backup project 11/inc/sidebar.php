
		<div class="sidebar clear">
			<div class="samesidebar clear">
				<h2>Categories</h2>
					<ul>
<?php
	$query = "SELECT * FROM `tbl_cat` ";
	$catagory = $db->select($query);
	if($catagory){
		while($result = $catagory->fetch_assoc()){
?>
						<li><a href="posts.php?catgory=<?= $result['id'];?>"><?= strtoupper($result['name']); ?></a></li>
<?php	} 
	}else{
?>
						<li><a href="#">No Catagory Created.</a></li>
<?php
	} ?>											
					</ul>
			</div>
			
			<div class="samesidebar clear">
				<h2>Latest articles</h2>
<?php
	$query = "SELECT * FROM `tbl_post` limit 5";
	$post = $db->select($query);
	if($post){
		while($result = $post->fetch_assoc()){
?>				
					<div class="popular clear">
						<h3><a href="post.php?id=<?= $result['id']; ?>"><?= ucwords($result['titel']);?></a></h3>
						<a href="post.php?id=<?= $result['id'];?>"><img src="admin/upload/<?= $result['img'];?>" alt="post image"/></a>
						<p><?= $fm->textShot($result['body'], 150);?></p>	
					</div>
<?php
	}	}else{ header('location:404.php'); 
} ?>					
			</div>
			
		</div>